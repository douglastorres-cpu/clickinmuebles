# NidoUrbano - Plataforma de Venta de Departamentos

NidoUrbano es una plataforma completa de venta de departamentos construida con Node.js, Express.js, MongoDB y Vanilla JavaScript. Ofrece una interfaz moderna para listar, buscar y contactar sobre propiedades residenciales en México.

## Características

- **Catálogo de Propiedades**: Listado completo de departamentos con filtros avanzados
- **Búsqueda y Filtros**: Filtrar por ciudad, precio, recámaras, tipo de propiedad
- **Galería de Imágenes**: Vista detallada de cada propiedad con múltiples imágenes
- **Panel Admin**: Gestión completa de departamentos y contactos
- **Sistema de Contactos**: Formularios para que los clientes se comuniquen
- **Autenticación JWT**: Panel administrativo protegido con tokens JWT
- **Base de Datos MongoDB**: Almacenamiento robusto con Mongoose
- **Diseño Responsivo**: Interfaz optimizada para desktop, tablet y móvil
- **Estadísticas**: Dashboard con métricas de propiedades y contactos

## Requisitos

- Node.js 14+
- MongoDB 4.4+
- npm o yarn

## Instalación

1. Clona o navega al directorio del proyecto:
```bash
cd nidourbano
```

2. Instala las dependencias:
```bash
npm install
```

3. Configura las variables de entorno (archivo `.env` incluido con valores por defecto):
```
PORT=3000
MONGODB_URI=mongodb://localhost:27017/nidourbano
JWT_SECRET=nidourbano_secret_2024_xyz
ADMIN_EMAIL=admin@nidourbano.com
ADMIN_PASSWORD=NidoUrbano2024!
```

4. Asegúrate que MongoDB está ejecutándose:
```bash
# En macOS con Homebrew
brew services start mongodb-community

# O ejecuta mongod directamente
mongod
```

5. Siembra la base de datos con datos de ejemplo:
```bash
npm run seed
```

6. Inicia el servidor:
```bash
npm start
```

El servidor estará disponible en `http://localhost:3000`

## Desarrollo

Para desarrollo con reinicio automático:
```bash
npm run dev
```

## Estructura del Proyecto

```
nidourbano/
├── models/                 # Modelos de Mongoose
│   ├── Apartment.js       # Modelo de departamentos
│   ├── Contact.js         # Modelo de contactos
│   └── Admin.js           # Modelo de administradores
├── routes/                 # Rutas de API
│   ├── apartments.js      # Endpoints de departamentos
│   ├── contacts.js        # Endpoints de contactos
│   └── admin.js           # Endpoints de autenticación y admin
├── middleware/             # Middleware personalizado
│   └── auth.js            # Verificación de JWT
├── seed/                   # Datos de semilla
│   └── seed.js            # Script para popular la BD
├── public/                 # Archivos estáticos
│   ├── index.html         # Página principal
│   ├── propiedades.html   # Listado de propiedades
│   ├── detalle.html       # Detalle de propiedad
│   ├── contacto.html      # Página de contacto
│   ├── admin.html         # Panel administrativo
│   ├── css/
│   │   └── style.css      # Estilos principales
│   └── js/
│       ├── main.js        # Funciones compartidas
│       ├── propiedades.js # Lógica de listado
│       ├── detalle.js     # Lógica de detalle
│       ├── contacto.js    # Lógica de contacto
│       └── admin.js       # Lógica de admin panel
├── server.js              # Punto de entrada
├── package.json           # Dependencias
├── .env                   # Variables de entorno
└── README.md              # Este archivo
```

## API Endpoints

### Departamentos
- `GET /api/apartments` - Listar con filtros y paginación
- `GET /api/apartments/featured` - Obtener destacados
- `GET /api/apartments/stats` - Estadísticas
- `GET /api/apartments/:id` - Detalle de departamento
- `POST /api/apartments` - Crear (protegido)
- `PUT /api/apartments/:id` - Actualizar (protegido)
- `DELETE /api/apartments/:id` - Eliminar (protegido)

### Contactos
- `POST /api/contacts` - Crear contacto
- `GET /api/contacts` - Listar contactos (protegido)
- `PUT /api/contacts/:id` - Actualizar estado (protegido)

### Admin
- `POST /api/admin/login` - Login de administrador
- `GET /api/admin/me` - Perfil actual (protegido)
- `GET /api/admin/dashboard/stats` - Estadísticas del dashboard (protegido)

## Credenciales de Prueba

Email: `admin@nidourbano.com`
Contraseña: `NidoUrbano2024!`

## Tecnologías Utilizadas

- **Backend**: Node.js, Express.js
- **Base de Datos**: MongoDB, Mongoose ODM
- **Autenticación**: JWT (jsonwebtoken)
- **Seguridad**: bcryptjs para hash de contraseñas
- **Frontend**: HTML5, CSS3, Bootstrap 5, Vanilla JavaScript
- **Iconos**: Font Awesome 6
- **Tipografía**: Google Fonts (Poppins)

## Funcionalidades Principales

### Lado Cliente
- Página principal con propiedades destacadas
- Búsqueda y filtrado avanzado
- Vistas de detalle de propiedades con galería
- Sistema de contacto para consultas
- Formularios responsivos

### Lado Admin
- Autenticación segura con JWT
- Gestión de departamentos (CRUD)
- Visualización y gestión de contactos
- Dashboard con estadísticas
- Modal para agregar/editar propiedades

## Notas de Desarrollo

- Todos los precios están en MXN (pesos mexicanos)
- Las imágenes usan Picsum Photos API para datos de prueba
- El sistema está completamente funcional sin necesidad de validación adicional
- El frontend es completamente responsivo
- Las búsquedas soportan búsqueda de texto en título, descripción y vecindario
- Los tokens JWT expiran en 24 horas

## Mejoras Futuras

- Integración con pasarelas de pago
- Sistema de favoritos/guardados
- Notificaciones por email
- Integración de mapas reales
- Galería mejorada con zoom
- Reportes avanzados
- Integración con redes sociales
- Sistema de calificaciones y reseñas

## Soporte

Para preguntas o soporte, contacta a: info@nidourbano.com

## Licencia

Todos los derechos reservados. NidoUrbano 2024.
