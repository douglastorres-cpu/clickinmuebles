require('dotenv').config();
const mongoose = require('mongoose');
const Admin = require('../models/Admin');
const Apartment = require('../models/Apartment');

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('✅ Conectado a MongoDB');
  } catch (err) {
    console.error('❌ Error conectando a MongoDB:', err.message);
    process.exit(1);
  }
};

const seedDatabase = async () => {
  try {
    // Clear existing apartments
    await Apartment.deleteMany({});
    console.log('🗑️  Departamentos previos eliminados');

    // Create default admin if none exists
    const existingAdmin = await Admin.findOne({ email: process.env.ADMIN_EMAIL });
    if (!existingAdmin) {
      const admin = new Admin({
        name: 'Administrador NidoUrbano',
        email: process.env.ADMIN_EMAIL,
        password: process.env.ADMIN_PASSWORD,
        role: 'super',
      });
      await admin.save();
      console.log('👤 Admin por defecto creado');
    } else {
      console.log('👤 Admin ya existe');
    }

    // Sample apartments data
    const apartments = [
      {
        title: 'Hermoso Departamento en Polanco con Terraza',
        description: 'Exclusivo departamento en Polanco, zona de alto nivel con vistas espectaculares, amenidades de clase mundial y seguridad 24/7.',
        price: 2500000,
        address: {
          street: 'Av. Presidente Masaryk 123',
          neighborhood: 'Polanco',
          city: 'CDMX',
          state: 'CDMX',
          zipCode: '11570',
          country: 'México',
        },
        details: {
          bedrooms: 2,
          bathrooms: 2,
          area: 120,
          floor: 8,
          totalFloors: 20,
          parking: true,
          furnished: false,
          petFriendly: true,
          age: 2,
        },
        amenities: ['Alberca', 'Gimnasio', 'Vigilancia', 'Roof Garden', 'Elevador'],
        mainImage: 'https://picsum.photos/seed/10/800/600',
        images: ['https://picsum.photos/seed/10/800/600', 'https://picsum.photos/seed/11/800/600', 'https://picsum.photos/seed/12/800/600'],
        status: 'disponible',
        featured: true,
        type: 'departamento',
      },
      {
        title: 'Moderno Loft en Condesa',
        description: 'Loft contemporáneo en el corazón de Condesa, perfecto para profesionales jóvenes. Ambiente bohemio con acceso a tiendas, cafés y restaurantes.',
        price: 1800000,
        address: {
          street: 'Calle Álvaro Obregón 45',
          neighborhood: 'Condesa',
          city: 'CDMX',
          state: 'CDMX',
          zipCode: '06500',
          country: 'México',
        },
        details: {
          bedrooms: 1,
          bathrooms: 1,
          area: 85,
          floor: 3,
          totalFloors: 5,
          parking: false,
          furnished: true,
          petFriendly: true,
          age: 5,
        },
        amenities: ['Elevador', 'Vigilancia', 'Azotea'],
        mainImage: 'https://picsum.photos/seed/20/800/600',
        images: ['https://picsum.photos/seed/20/800/600', 'https://picsum.photos/seed/21/800/600', 'https://picsum.photos/seed/22/800/600'],
        status: 'disponible',
        featured: true,
        type: 'loft',
      },
      {
        title: 'Penthouse en Roma Norte',
        description: 'Penthouse de lujo en Roma Norte con terraza panorámica, acabados premium y distribución moderna. Ubicación privilegiada en zona gastronómica.',
        price: 4200000,
        address: {
          street: 'Calle Yucatán 78',
          neighborhood: 'Roma Norte',
          city: 'CDMX',
          state: 'CDMX',
          zipCode: '06700',
          country: 'México',
        },
        details: {
          bedrooms: 3,
          bathrooms: 2,
          area: 180,
          floor: 15,
          totalFloors: 15,
          parking: true,
          furnished: false,
          petFriendly: true,
          age: 3,
        },
        amenities: ['Alberca', 'Gimnasio', 'Vigilancia', 'Roof Garden', 'Elevador', 'Home Theater'],
        mainImage: 'https://picsum.photos/seed/30/800/600',
        images: ['https://picsum.photos/seed/30/800/600', 'https://picsum.photos/seed/31/800/600', 'https://picsum.photos/seed/32/800/600'],
        status: 'disponible',
        featured: true,
        type: 'penthouse',
      },
      {
        title: 'Estudio Compacto en Santa Fe',
        description: 'Perfecto para inversionistas. Estudio bien ubicado en Santa Fe con proyección de plusvalía. Acceso a centros comerciales y corporativos.',
        price: 800000,
        address: {
          street: 'Av. Bosque de Chapultepec 500',
          neighborhood: 'Santa Fe',
          city: 'CDMX',
          state: 'CDMX',
          zipCode: '01210',
          country: 'México',
        },
        details: {
          bedrooms: 0,
          bathrooms: 1,
          area: 45,
          floor: 5,
          totalFloors: 12,
          parking: true,
          furnished: false,
          petFriendly: false,
          age: 1,
        },
        amenities: ['Elevador', 'Vigilancia', 'Gimnasio'],
        mainImage: 'https://picsum.photos/seed/40/800/600',
        images: ['https://picsum.photos/seed/40/800/600', 'https://picsum.photos/seed/41/800/600', 'https://picsum.photos/seed/42/800/600'],
        status: 'disponible',
        featured: false,
        type: 'estudio',
      },
      {
        title: 'Departamento Familiar en Coyoacán',
        description: 'Amplio departamento para familia, con acabados rústicos mexicanos. Zona tranquila con acceso a escuelas y parques infantiles.',
        price: 1500000,
        address: {
          street: 'Avenida Universidad 234',
          neighborhood: 'Coyoacán',
          city: 'CDMX',
          state: 'CDMX',
          zipCode: '04000',
          country: 'México',
        },
        details: {
          bedrooms: 3,
          bathrooms: 2,
          area: 150,
          floor: 2,
          totalFloors: 3,
          parking: true,
          furnished: false,
          petFriendly: true,
          age: 10,
        },
        amenities: ['Patio', 'Vigilancia', 'Azotea'],
        mainImage: 'https://picsum.photos/seed/50/800/600',
        images: ['https://picsum.photos/seed/50/800/600', 'https://picsum.photos/seed/51/800/600', 'https://picsum.photos/seed/52/800/600'],
        status: 'vendido',
        featured: false,
        type: 'departamento',
      },
      {
        title: 'Loft Industrial en Narvarte',
        description: 'Loft de estilo industrial con techos altos, acabados contemporáneos. Ideal para ejecutivos o profesionales independientes.',
        price: 2100000,
        address: {
          street: 'Calle Tolstoi 89',
          neighborhood: 'Narvarte',
          city: 'CDMX',
          state: 'CDMX',
          zipCode: '03600',
          country: 'México',
        },
        details: {
          bedrooms: 2,
          bathrooms: 2,
          area: 110,
          floor: 4,
          totalFloors: 6,
          parking: true,
          furnished: false,
          petFriendly: true,
          age: 4,
        },
        amenities: ['Elevador', 'Vigilancia', 'Azotea', 'Cochera'],
        mainImage: 'https://picsum.photos/seed/60/800/600',
        images: ['https://picsum.photos/seed/60/800/600', 'https://picsum.photos/seed/61/800/600', 'https://picsum.photos/seed/62/800/600'],
        status: 'disponible',
        featured: true,
        type: 'loft',
      },
      {
        title: 'Departamento en Del Valle',
        description: 'Cómodo departamento en la tranquila zona de Del Valle, con todos los servicios a la mano. Ideal para familias o jóvenes profesionales.',
        price: 1200000,
        address: {
          street: 'Calle Xola 123',
          neighborhood: 'Del Valle',
          city: 'CDMX',
          state: 'CDMX',
          zipCode: '03100',
          country: 'México',
        },
        details: {
          bedrooms: 2,
          bathrooms: 1,
          area: 95,
          floor: 3,
          totalFloors: 8,
          parking: true,
          furnished: false,
          petFriendly: true,
          age: 6,
        },
        amenities: ['Elevador', 'Vigilancia'],
        mainImage: 'https://picsum.photos/seed/70/800/600',
        images: ['https://picsum.photos/seed/70/800/600', 'https://picsum.photos/seed/71/800/600', 'https://picsum.photos/seed/72/800/600'],
        status: 'apartado',
        featured: false,
        type: 'departamento',
      },
      {
        title: 'Penthouse con Vistas al Bosque en Lomas',
        description: 'Exclusivo penthouse en Lomas de Chapultepec con vistas al bosque. Acabados de lujo, privacidad total y acceso restringido.',
        price: 8500000,
        address: {
          street: 'Paseo de las Lomas 567',
          neighborhood: 'Lomas de Chapultepec',
          city: 'CDMX',
          state: 'CDMX',
          zipCode: '11000',
          country: 'México',
        },
        details: {
          bedrooms: 4,
          bathrooms: 3,
          area: 200,
          floor: 25,
          totalFloors: 25,
          parking: true,
          furnished: false,
          petFriendly: true,
          age: 1,
        },
        amenities: ['Alberca', 'Gimnasio', 'Vigilancia', 'Roof Garden', 'Elevador', 'Home Theater', 'Sauna'],
        mainImage: 'https://picsum.photos/seed/80/800/600',
        images: ['https://picsum.photos/seed/80/800/600', 'https://picsum.photos/seed/81/800/600', 'https://picsum.photos/seed/82/800/600'],
        status: 'disponible',
        featured: true,
        type: 'penthouse',
      },
      {
        title: 'Departamento Moderno en Providencia, Guadalajara',
        description: 'Hermoso departamento en Providencia con acabados modernos y vista a la ciudad. Zona segura y con excelentes servicios.',
        price: 1400000,
        address: {
          street: 'Av. Patria 456',
          neighborhood: 'Providencia',
          city: 'Guadalajara',
          state: 'Jalisco',
          zipCode: '44620',
          country: 'México',
        },
        details: {
          bedrooms: 2,
          bathrooms: 2,
          area: 100,
          floor: 6,
          totalFloors: 12,
          parking: true,
          furnished: true,
          petFriendly: true,
          age: 3,
        },
        amenities: ['Alberca', 'Elevador', 'Vigilancia', 'Gimnasio'],
        mainImage: 'https://picsum.photos/seed/90/800/600',
        images: ['https://picsum.photos/seed/90/800/600', 'https://picsum.photos/seed/91/800/600', 'https://picsum.photos/seed/92/800/600'],
        status: 'disponible',
        featured: false,
        type: 'departamento',
      },
      {
        title: 'Loft en Chapalita, Guadalajara',
        description: 'Trendy loft en la zona de Chapalita con diseño contemporáneo. Perfecto para profesionales creativos. Centro gastronómico y cultural.',
        price: 1900000,
        address: {
          street: 'Av. Guadalupe 789',
          neighborhood: 'Chapalita',
          city: 'Guadalajara',
          state: 'Jalisco',
          zipCode: '44550',
          country: 'México',
        },
        details: {
          bedrooms: 1,
          bathrooms: 1,
          area: 90,
          floor: 2,
          totalFloors: 4,
          parking: true,
          furnished: true,
          petFriendly: true,
          age: 2,
        },
        amenities: ['Elevador', 'Vigilancia', 'Azotea'],
        mainImage: 'https://picsum.photos/seed/100/800/600',
        images: ['https://picsum.photos/seed/100/800/600', 'https://picsum.photos/seed/101/800/600', 'https://picsum.photos/seed/102/800/600'],
        status: 'vendido',
        featured: false,
        type: 'loft',
      },
      {
        title: 'Estudio de Inversión en Santa Fe',
        description: 'Oportunidad de inversión en Santa Fe. Estudio listo para rentar. Excelente retorno de inversión garantizado.',
        price: 950000,
        address: {
          street: 'Av. Reforma 234',
          neighborhood: 'Santa Fe',
          city: 'CDMX',
          state: 'CDMX',
          zipCode: '01210',
          country: 'México',
        },
        details: {
          bedrooms: 0,
          bathrooms: 1,
          area: 50,
          floor: 10,
          totalFloors: 15,
          parking: true,
          furnished: true,
          petFriendly: false,
          age: 1,
        },
        amenities: ['Elevador', 'Vigilancia', 'Gimnasio'],
        mainImage: 'https://picsum.photos/seed/110/800/600',
        images: ['https://picsum.photos/seed/110/800/600', 'https://picsum.photos/seed/111/800/600', 'https://picsum.photos/seed/112/800/600'],
        status: 'apartado',
        featured: false,
        type: 'estudio',
      },
      {
        title: 'Departamento Amplio en Roma',
        description: 'Departamento en Roma Sur con gran distribución, cocina integral moderna. Zona con alto nivel de amenidades y seguridad.',
        price: 2800000,
        address: {
          street: 'Calle Zacatecas 345',
          neighborhood: 'Roma Sur',
          city: 'CDMX',
          state: 'CDMX',
          zipCode: '06760',
          country: 'México',
        },
        details: {
          bedrooms: 3,
          bathrooms: 2,
          area: 140,
          floor: 7,
          totalFloors: 10,
          parking: true,
          furnished: false,
          petFriendly: true,
          age: 4,
        },
        amenities: ['Alberca', 'Gimnasio', 'Vigilancia', 'Elevador'],
        mainImage: 'https://picsum.photos/seed/120/800/600',
        images: ['https://picsum.photos/seed/120/800/600', 'https://picsum.photos/seed/121/800/600', 'https://picsum.photos/seed/122/800/600'],
        status: 'disponible',
        featured: false,
        type: 'departamento',
      },
      {
        title: 'Apartado: Departamento en Polanco',
        description: 'Hermoso departamento en Polanco, actualmente apartado. Ubicación privilegiada con acceso a centros comerciales y gastronómicos.',
        price: 3200000,
        address: {
          street: 'Av. Ejército Nacional 456',
          neighborhood: 'Polanco',
          city: 'CDMX',
          state: 'CDMX',
          zipCode: '11570',
          country: 'México',
        },
        details: {
          bedrooms: 3,
          bathrooms: 2,
          area: 130,
          floor: 9,
          totalFloors: 20,
          parking: true,
          furnished: false,
          petFriendly: false,
          age: 2,
        },
        amenities: ['Alberca', 'Gimnasio', 'Vigilancia', 'Roof Garden', 'Elevador'],
        mainImage: 'https://picsum.photos/seed/130/800/600',
        images: ['https://picsum.photos/seed/130/800/600', 'https://picsum.photos/seed/131/800/600', 'https://picsum.photos/seed/132/800/600'],
        status: 'apartado',
        featured: true,
        type: 'departamento',
      },
    ];

    await Apartment.insertMany(apartments);
    console.log('🏢 15 departamentos de muestra creados');

    console.log('\n✅ Base de datos sembrada exitosamente');
  } catch (err) {
    console.error('❌ Error sembrando base de datos:', err.message);
  } finally {
    await mongoose.connection.close();
    console.log('🔌 Conexión a MongoDB cerrada');
  }
};

const runSeed = async () => {
  await connectDB();
  await seedDatabase();
};

runSeed();
