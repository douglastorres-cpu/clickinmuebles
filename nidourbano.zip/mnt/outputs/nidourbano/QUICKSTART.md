# NidoUrbano - Guía de Inicio Rápido

## ¿Qué es NidoUrbano?

NidoUrbano es una aplicación web completa de venta de departamentos con:
- Catálogo de propiedades con búsqueda avanzada
- Panel administrativo seguro con autenticación JWT
- Base de datos MongoDB con 15 propiedades de ejemplo
- Interfaz moderna y responsiva

## Requisitos Previos

1. **Node.js** 14 o superior
2. **MongoDB** 4.4 o superior ejecutándose localmente

### Verificar instalación:
```bash
node --version      # Debe ser v14.0.0 o mayor
npm --version       # Debe estar disponible
mongod --version    # Debe estar instalado
```

## Instalación (3 pasos)

### 1. Instalar dependencias
```bash
cd nidourbano
npm install
```

### 2. Iniciar MongoDB
```bash
# En una terminal separada
mongod
```

### 3. Ejecutar servidor
```bash
npm start
```

Deberías ver:
```
✅ MongoDB conectado exitosamente
🚀 Servidor NidoUrbano ejecutándose en puerto 3000
```

## Primer Uso

### Abrir la aplicación
1. Abre http://localhost:3000 en tu navegador
2. Explora la página principal con propiedades destacadas
3. Usa "Propiedades" para ver el catálogo completo con filtros

### Acceder al Panel Admin
1. Haz clic en "Admin" en la esquina superior derecha
2. Usa las credenciales:
   - Email: `admin@nidourbano.com`
   - Contraseña: `NidoUrbano2024!`
3. Verás un dashboard con estadísticas y gestión de propiedades

## Cargar Datos de Ejemplo

Ya vienen incluidos 15 departamentos de muestra, pero si quieres recargarlos:

```bash
npm run seed
```

Esto creará:
- Admin predeterminado
- 15 departamentos en CDMX y Guadalajara
- Información lista para exploreación

## Estructura Rápida

```
├── server.js           ← Punto de entrada
├── models/            ← Esquemas de MongoDB
├── routes/            ← Endpoints de API
├── middleware/        ← Autenticación JWT
├── public/            ← Interfaz web
│   ├── *.html         ← Páginas principales
│   ├── css/style.css  ← Estilos
│   └── js/            ← Lógica del cliente
└── seed/              ← Datos de ejemplo
```

## APIs Disponibles

### Búsqueda de Departamentos
```javascript
GET /api/apartments?city=CDMX&minPrice=1000000&limit=9&page=1
```

### Crear Contacto
```javascript
POST /api/contacts
{
  "name": "Juan",
  "email": "juan@example.com",
  "phone": "5512345678",
  "message": "Interesado en...",
  "apartmentId": "..."
}
```

### Login Admin
```javascript
POST /api/admin/login
{
  "email": "admin@nidourbano.com",
  "password": "NidoUrbano2024!"
}
```

## Características Clave

### Frontend
✓ Página principal con hero section
✓ Búsqueda y filtros avanzados
✓ Galería de imágenes
✓ Formulario de contacto
✓ Diseño responsivo (mobile/tablet/desktop)

### Backend
✓ API RESTful completa
✓ Autenticación JWT
✓ CRUD de departamentos
✓ Gestión de contactos
✓ Validaciones de datos

### Admin
✓ Dashboard con estadísticas
✓ Gestión de departamentos
✓ Gestión de contactos
✓ Modal para agregar/editar

## Desarrollo

### Modo desarrollo con recarga automática:
```bash
npm run dev
```

### Puntos de entrada útiles:
- **Frontend**: http://localhost:3000
- **API**: http://localhost:3000/api/apartments
- **Admin**: http://localhost:3000/admin.html

## Solución de Problemas

### "Error conectando a MongoDB"
- Asegúrate que MongoDB está corriendo: `mongod`
- Verifica que el URI en `.env` es correcto

### Puerto 3000 en uso
Cambia el puerto en `.env`:
```
PORT=3001
```

### Las imágenes no cargan
- Las imágenes vienen de picsum.photos
- Necesitas conexión a internet

## Próximos Pasos

1. **Explorar**: Abre http://localhost:3000 y navega por la app
2. **Admin**: Prueba el panel con las credenciales de ejemplo
3. **Datos**: Modifica/agrega departamentos desde el admin
4. **Código**: Personaliza estilos en `public/css/style.css`

## Tech Stack

- Node.js + Express
- MongoDB + Mongoose
- HTML5 + CSS3 (Bootstrap 5)
- Vanilla JavaScript
- JWT Auth

## Documentación Completa

Ver `README.md` para documentación detallada de:
- Estructura del proyecto
- Endpoints de API
- Variables de entorno
- Mejoras futuras

---

¿Preguntas? El código está bien comentado y listo para personalizar.
