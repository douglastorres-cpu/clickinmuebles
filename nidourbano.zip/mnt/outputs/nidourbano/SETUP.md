# NidoUrbano - Configuración Rápida

## Instalación Rápida (Menos de 5 minutos)

### Paso 1: Instalar Dependencias
```bash
npm install
```

### Paso 2: Iniciar MongoDB
Abre una terminal separada y ejecuta:
```bash
mongod
```

### Paso 3: Ejecutar Servidor
```bash
npm start
```

Deberías ver:
```
✅ MongoDB conectado exitosamente
🚀 Servidor NidoUrbano ejecutándose en puerto 3000
```

### Paso 4: Cargar Datos (Opcional)
Si quieres cargar 15 departamentos de ejemplo:
```bash
npm run seed
```

## Acceso

| Página | URL |
|--------|-----|
| Inicio | http://localhost:3000 |
| Propiedades | http://localhost:3000/propiedades.html |
| Admin | http://localhost:3000/admin.html |

## Login Admin

```
Email: admin@nidourbano.com
Contraseña: NidoUrbano2024!
```

## Desarrollo

Para desarrollo con reinicio automático:
```bash
npm run dev
```

## Estructura

```
nidourbano/
├── server.js              → Punto de entrada
├── models/                → Esquemas MongoDB
├── routes/                → Endpoints API
├── public/                → Interfaz web
│   ├── *.html
│   ├── css/style.css
│   └── js/
└── seed/                  → Datos de ejemplo
```

## Endpoints API

### Departamentos
- GET /api/apartments (listado)
- GET /api/apartments/:id (detalle)
- POST /api/apartments (crear, protegido)

### Contactos
- POST /api/contacts (crear)
- GET /api/contacts (listar, protegido)

### Admin
- POST /api/admin/login
- GET /api/admin/dashboard/stats

## Solución de Problemas

### MongoDB no conecta
- Asegúrate que `mongod` está corriendo
- Verifica la URI en `.env`

### Puerto 3000 ocupado
- Cambia PORT en `.env`
- O cierra la aplicación anterior

### Las imágenes no cargan
- Necesitas conexión a internet (Picsum Photos)

## Personalización

- Colores: Ver `:root` en `public/css/style.css`
- Texto: Modificar archivos HTML
- Lógica: Actualizar archivos JS
- Base de datos: Modificar modelos en `models/`

## Producción

1. Cambiar variables en `.env`
2. Usar MongoDB en la nube (Atlas)
3. Deployar en servidor (Heroku, AWS, etc.)

Ver `README.md` para documentación completa.
