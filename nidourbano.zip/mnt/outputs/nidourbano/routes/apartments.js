const express = require('express');
const router = express.Router();
const Apartment = require('../models/Apartment');
const { verifyToken } = require('../middleware/auth');

// GET all apartments with filters and pagination
router.get('/', async (req, res) => {
  try {
    const {
      page = 1,
      limit = 9,
      minPrice,
      maxPrice,
      bedrooms,
      city,
      status,
      type,
      featured,
      search,
    } = req.query;

    const filter = {};

    if (minPrice) filter.price = { $gte: parseInt(minPrice) };
    if (maxPrice) {
      filter.price = filter.price || {};
      filter.price.$lte = parseInt(maxPrice);
    }
    if (bedrooms) filter['details.bedrooms'] = parseInt(bedrooms);
    if (city) filter['address.city'] = city;
    if (status) filter.status = status;
    if (type) filter.type = type;
    if (featured === 'true') filter.featured = true;

    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { 'address.neighborhood': { $regex: search, $options: 'i' } },
      ];
    }

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    const apartments = await Apartment.find(filter)
      .skip(skip)
      .limit(limitNum)
      .sort({ createdAt: -1 });

    const total = await Apartment.countDocuments(filter);

    res.json({
      apartments,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        pages: Math.ceil(total / limitNum),
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET featured apartments
router.get('/featured', async (req, res) => {
  try {
    const apartments = await Apartment.find({
      featured: true,
      status: 'disponible',
    })
      .limit(6)
      .sort({ createdAt: -1 });

    res.json(apartments);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET statistics
router.get('/stats', async (req, res) => {
  try {
    const total = await Apartment.countDocuments();
    const disponible = await Apartment.countDocuments({ status: 'disponible' });
    const vendido = await Apartment.countDocuments({ status: 'vendido' });
    const apartado = await Apartment.countDocuments({ status: 'apartado' });

    const priceData = await Apartment.aggregate([
      {
        $group: {
          _id: null,
          avgPrice: { $avg: '$price' },
        },
      },
    ]);

    const avgPrice = priceData[0]?.avgPrice || 0;

    res.json({
      total,
      disponible,
      vendido,
      apartado,
      avgPrice: Math.round(avgPrice),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET single apartment
router.get('/:id', async (req, res) => {
  try {
    const apartment = await Apartment.findById(req.params.id);

    if (!apartment) {
      return res.status(404).json({ error: 'Departamento no encontrado' });
    }

    res.json(apartment);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST create apartment (protected)
router.post('/', verifyToken, async (req, res) => {
  try {
    const apartment = new Apartment(req.body);
    await apartment.save();
    res.status(201).json(apartment);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT update apartment (protected)
router.put('/:id', verifyToken, async (req, res) => {
  try {
    const apartment = await Apartment.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });

    if (!apartment) {
      return res.status(404).json({ error: 'Departamento no encontrado' });
    }

    res.json(apartment);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE apartment (protected)
router.delete('/:id', verifyToken, async (req, res) => {
  try {
    const apartment = await Apartment.findByIdAndDelete(req.params.id);

    if (!apartment) {
      return res.status(404).json({ error: 'Departamento no encontrado' });
    }

    res.json({ message: 'Departamento eliminado exitosamente' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
