const express = require('express');
const router = express.Router();
const Contact = require('../models/Contact');
const { verifyToken } = require('../middleware/auth');

// POST create contact (public)
router.post('/', async (req, res) => {
  try {
    const contact = new Contact(req.body);
    await contact.save();
    res.status(201).json({
      message: 'Contacto guardado exitosamente',
      contact,
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// GET all contacts (protected)
router.get('/', verifyToken, async (req, res) => {
  try {
    const { status } = req.query;
    const filter = {};

    if (status) {
      filter.status = status;
    }

    const contacts = await Contact.find(filter).sort({ createdAt: -1 });

    res.json(contacts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT update contact status (protected)
router.put('/:id', verifyToken, async (req, res) => {
  try {
    const { status } = req.body;

    const contact = await Contact.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true, runValidators: true }
    );

    if (!contact) {
      return res.status(404).json({ error: 'Contacto no encontrado' });
    }

    res.json(contact);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;
