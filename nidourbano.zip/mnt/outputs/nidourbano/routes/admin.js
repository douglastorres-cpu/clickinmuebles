const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');
const Apartment = require('../models/Apartment');
const Contact = require('../models/Contact');
const { verifyToken } = require('../middleware/auth');

// POST login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email y contraseña requeridos' });
    }

    const admin = await Admin.findOne({ email }).select('+password');

    if (!admin) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const isPasswordValid = await admin.comparePassword(password);

    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const token = jwt.sign(
      { id: admin._id, email: admin.email, role: admin.role },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      admin: {
        id: admin._id,
        name: admin.name,
        email: admin.email,
        role: admin.role,
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET current admin profile (protected)
router.get('/me', verifyToken, async (req, res) => {
  try {
    const admin = await Admin.findById(req.user.id);

    if (!admin) {
      return res.status(404).json({ error: 'Admin no encontrado' });
    }

    res.json(admin);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET dashboard stats (protected)
router.get('/dashboard/stats', verifyToken, async (req, res) => {
  try {
    const totalApartments = await Apartment.countDocuments();
    const available = await Apartment.countDocuments({ status: 'disponible' });
    const sold = await Apartment.countDocuments({ status: 'vendido' });
    const reserved = await Apartment.countDocuments({ status: 'apartado' });
    const totalContacts = await Contact.countDocuments();
    const newContacts = await Contact.countDocuments({ status: 'nuevo' });
    const featuredCount = await Apartment.countDocuments({ featured: true });

    res.json({
      totalApartments,
      available,
      sold,
      reserved,
      totalContacts,
      newContacts,
      featuredCount,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
