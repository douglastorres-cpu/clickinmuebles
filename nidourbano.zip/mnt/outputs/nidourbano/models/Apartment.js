const mongoose = require('mongoose');

const apartmentSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'El título es requerido'],
  },
  description: {
    type: String,
    required: [true, 'La descripción es requerida'],
  },
  price: {
    type: Number,
    required: [true, 'El precio es requerido'],
  },
  address: {
    street: String,
    neighborhood: String,
    city: String,
    state: String,
    zipCode: String,
    country: {
      type: String,
      default: 'México',
    },
  },
  details: {
    bedrooms: Number,
    bathrooms: Number,
    area: Number,
    floor: Number,
    totalFloors: Number,
    parking: {
      type: Boolean,
      default: false,
    },
    furnished: {
      type: Boolean,
      default: false,
    },
    petFriendly: {
      type: Boolean,
      default: false,
    },
    age: Number,
  },
  amenities: [String],
  images: [String],
  mainImage: String,
  status: {
    type: String,
    enum: ['disponible', 'vendido', 'apartado'],
    default: 'disponible',
  },
  featured: {
    type: Boolean,
    default: false,
  },
  type: {
    type: String,
    enum: ['departamento', 'penthouse', 'loft', 'estudio'],
    default: 'departamento',
  },
}, {
  timestamps: true,
});

// Virtual para precio por m²
apartmentSchema.virtual('pricePerM2').get(function() {
  if (this.details && this.details.area) {
    return Math.round(this.price / this.details.area);
  }
  return 0;
});

// Ensure virtuals are included in JSON
apartmentSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('Apartment', apartmentSchema);
