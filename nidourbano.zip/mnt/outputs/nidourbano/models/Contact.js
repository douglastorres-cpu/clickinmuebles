const mongoose = require('mongoose');

const contactSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'El nombre es requerido'],
  },
  email: {
    type: String,
    required: [true, 'El email es requerido'],
    match: [/.+@.+\..+/, 'Por favor ingresa un email válido'],
  },
  phone: {
    type: String,
    required: [true, 'El teléfono es requerido'],
  },
  message: {
    type: String,
    required: [true, 'El mensaje es requerido'],
  },
  apartmentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Apartment',
    default: null,
  },
  apartmentTitle: String,
  status: {
    type: String,
    enum: ['nuevo', 'contactado', 'cerrado'],
    default: 'nuevo',
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model('Contact', contactSchema);
