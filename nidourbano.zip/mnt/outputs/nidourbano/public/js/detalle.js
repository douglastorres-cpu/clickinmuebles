let currentApartment = null;

// Get apartment ID from URL
function getApartmentId() {
  const params = new URLSearchParams(window.location.search);
  return params.get('id');
}

// Load apartment details
async function loadApartmentDetails() {
  const id = getApartmentId();
  if (!id) {
    showToast('ID de departamento no válido', 'error');
    window.location.href = '/propiedades.html';
    return;
  }

  const container = document.getElementById('detail-container');
  showLoading(container);

  try {
    const res = await fetch(`${API_BASE}/api/apartments/${id}`);
    if (!res.ok) throw new Error('Departamento no encontrado');

    const apartment = await res.json();
    currentApartment = apartment;

    hideLoading(container);
    renderApartmentDetail(apartment);
    loadSimilarApartments(apartment.address.city, apartment._id);
  } catch (err) {
    hideLoading(container);
    console.error('Error loading apartment:', err);
    showToast('Error al cargar el departamento', 'error');
    window.location.href = '/propiedades.html';
  }
}

// Render apartment detail
function renderApartmentDetail(apt) {
  const container = document.getElementById('detail-container');

  const amenitiesHtml = apt.amenities
    .map(amenity => `<span class="amenity-badge">${amenity}</span>`)
    .join('');

  const imagesHtml = apt.images
    .map((img, idx) => `<div class="thumbnail ${idx === 0 ? 'active' : ''}" onclick="changeMainImage('${img}')"><img src="${img}" alt="Imagen ${idx + 1}"></div>`)
    .join('');

  const statusText = {
    disponible: 'Disponible',
    vendido: 'Vendido',
    apartado: 'Apartado',
  };

  container.innerHTML = `
    <div class="detail-container">
      <div class="image-gallery">
        <div class="main-image">
          <img src="${apt.mainImage || apt.images[0]}" id="main-image" alt="${apt.title}">
        </div>
        <div class="thumbnail-images">
          ${imagesHtml}
        </div>
      </div>

      <div class="detail-info">
        <div class="detail-header">
          <h1 class="detail-title">${apt.title}</h1>
          <div class="detail-price">${formatPrice(apt.price)}</div>
          <div class="detail-pills">
            <span class="detail-pill badge badge-${apt.status}">${statusText[apt.status]}</span>
            <span class="detail-pill">${apt.type.toUpperCase()}</span>
            ${apt.pricePerM2 ? `<span class="detail-pill">$${apt.pricePerM2.toLocaleString('es-MX')}/m²</span>` : ''}
          </div>
        </div>

        <div class="tabs">
          <button class="tab active" onclick="switchTab(event, 'description')">Descripción</button>
          <button class="tab" onclick="switchTab(event, 'features')">Características</button>
          <button class="tab" onclick="switchTab(event, 'amenities')">Amenidades</button>
        </div>

        <div id="description" class="tab-content active">
          <p>${apt.description}</p>
        </div>

        <div id="features" class="tab-content">
          <div class="info-grid">
            ${apt.details.bedrooms ? `
              <div class="info-item">
                <div class="info-label">Recámaras</div>
                <div class="info-value">${apt.details.bedrooms}</div>
              </div>
            ` : ''}
            ${apt.details.bathrooms ? `
              <div class="info-item">
                <div class="info-label">Baños</div>
                <div class="info-value">${apt.details.bathrooms}</div>
              </div>
            ` : ''}
            ${apt.details.area ? `
              <div class="info-item">
                <div class="info-label">Área</div>
                <div class="info-value">${apt.details.area} m²</div>
              </div>
            ` : ''}
            ${apt.details.floor ? `
              <div class="info-item">
                <div class="info-label">Piso</div>
                <div class="info-value">${apt.details.floor}${apt.details.totalFloors ? ` de ${apt.details.totalFloors}` : ''}</div>
              </div>
            ` : ''}
            ${apt.details.parking !== undefined ? `
              <div class="info-item">
                <div class="info-label">Estacionamiento</div>
                <div class="info-value">${apt.details.parking ? '✓ Sí' : '✗ No'}</div>
              </div>
            ` : ''}
            ${apt.details.furnished !== undefined ? `
              <div class="info-item">
                <div class="info-label">Amueblado</div>
                <div class="info-value">${apt.details.furnished ? '✓ Sí' : '✗ No'}</div>
              </div>
            ` : ''}
            ${apt.details.petFriendly !== undefined ? `
              <div class="info-item">
                <div class="info-label">Mascotas</div>
                <div class="info-value">${apt.details.petFriendly ? '✓ Permitidas' : '✗ No permitidas'}</div>
              </div>
            ` : ''}
            ${apt.details.age ? `
              <div class="info-item">
                <div class="info-label">Antigüedad</div>
                <div class="info-value">${apt.details.age} años</div>
              </div>
            ` : ''}
          </div>

          <h3>Ubicación</h3>
          <div class="info-grid">
            <div class="info-item">
              <div class="info-label">Calle</div>
              <div class="info-value">${apt.address.street}</div>
            </div>
            <div class="info-item">
              <div class="info-label">Vecindario</div>
              <div class="info-value">${apt.address.neighborhood}</div>
            </div>
            <div class="info-item">
              <div class="info-label">Ciudad</div>
              <div class="info-value">${apt.address.city}</div>
            </div>
            <div class="info-item">
              <div class="info-label">Código Postal</div>
              <div class="info-value">${apt.address.zipCode}</div>
            </div>
          </div>
        </div>

        <div id="amenities" class="tab-content">
          <div class="amenities-list">
            ${amenitiesHtml}
          </div>
        </div>

        <hr style="margin: 2rem 0;">

        <h3>Contacto</h3>
        <form id="contact-form" onsubmit="submitContactForm(event)">
          <div class="form-group">
            <label for="name">Nombre *</label>
            <input type="text" id="name" name="name" required>
          </div>
          <div class="form-group">
            <label for="email">Email *</label>
            <input type="email" id="email" name="email" required>
          </div>
          <div class="form-group">
            <label for="phone">Teléfono *</label>
            <input type="tel" id="phone" name="phone" required>
          </div>
          <div class="form-group">
            <label for="message">Mensaje *</label>
            <textarea id="message" name="message" required placeholder="Cuéntanos por qué te interesa este departamento..."></textarea>
          </div>
          <input type="hidden" id="apartmentId" value="${apt._id}">
          <input type="hidden" id="apartmentTitle" value="${apt.title}">
          <button type="submit" class="btn-submit">Enviar Consulta</button>
        </form>
      </div>
    </div>
  `;
}

// Change main image
function changeMainImage(imageSrc) {
  const mainImage = document.getElementById('main-image');
  mainImage.src = imageSrc;

  // Update active thumbnail
  document.querySelectorAll('.thumbnail').forEach(thumb => {
    thumb.classList.remove('active');
  });
  event.target.closest('.thumbnail').classList.add('active');
}

// Switch tabs
function switchTab(e, tabId) {
  e.preventDefault();

  // Hide all tabs
  document.querySelectorAll('.tab-content').forEach(tab => {
    tab.classList.remove('active');
  });

  // Remove active from all buttons
  document.querySelectorAll('.tab').forEach(btn => {
    btn.classList.remove('active');
  });

  // Show selected tab
  document.getElementById(tabId).classList.add('active');
  e.target.classList.add('active');
}

// Submit contact form
async function submitContactForm(e) {
  e.preventDefault();

  const formData = {
    name: document.getElementById('name').value,
    email: document.getElementById('email').value,
    phone: document.getElementById('phone').value,
    message: document.getElementById('message').value,
    apartmentId: document.getElementById('apartmentId').value,
    apartmentTitle: document.getElementById('apartmentTitle').value,
  };

  try {
    const res = await fetch(`${API_BASE}/api/contacts`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    if (!res.ok) throw new Error('Error al enviar');

    showToast('¡Consulta enviada exitosamente! Te contactaremos pronto.', 'success');
    document.getElementById('contact-form').reset();
  } catch (err) {
    console.error('Error submitting contact:', err);
    showToast('Error al enviar consulta. Intenta de nuevo.', 'error');
  }
}

// Load similar apartments
async function loadSimilarApartments(city, excludeId) {
  try {
    const res = await fetch(`${API_BASE}/api/apartments?city=${city}&limit=3&status=disponible`);
    const data = await res.json();

    const similar = data.apartments.filter(apt => apt._id !== excludeId).slice(0, 3);

    if (similar.length > 0) {
      const container = document.getElementById('similar-apartments');
      if (container) {
        container.innerHTML = similar.map(apt => createApartmentCard(apt)).join('');
      }
    }
  } catch (err) {
    console.error('Error loading similar apartments:', err);
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadApartmentDetails();
});
