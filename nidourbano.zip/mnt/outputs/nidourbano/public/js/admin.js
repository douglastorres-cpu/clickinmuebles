const TOKEN_KEY = 'nidourbano_token';
let currentAdmin = null;
let currentTab = 'apartments';

// Check authentication
function checkAuth() {
  const token = localStorage.getItem(TOKEN_KEY);
  const loginForm = document.getElementById('login-form');
  const dashboard = document.getElementById('admin-dashboard');

  if (token) {
    loginForm.style.display = 'none';
    dashboard.style.display = 'block';
    loadDashboard();
  } else {
    loginForm.style.display = 'flex';
    dashboard.style.display = 'none';
  }
}

// Handle login
async function handleLogin(e) {
  e.preventDefault();

  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;
  const btn = e.target.querySelector('.btn-submit');
  const originalText = btn.textContent;

  btn.disabled = true;
  btn.textContent = 'Iniciando sesión...';

  try {
    const res = await fetch(`${API_BASE}/api/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    if (!res.ok) throw new Error('Credenciales inválidas');

    const data = await res.json();
    localStorage.setItem(TOKEN_KEY, data.token);
    currentAdmin = data.admin;

    showToast('¡Iniciaste sesión exitosamente!', 'success');
    checkAuth();
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = originalText;
  }
}

// Handle logout
function handleLogout() {
  localStorage.removeItem(TOKEN_KEY);
  currentAdmin = null;
  checkAuth();
  showToast('Sesión cerrada', 'info');
}

// Get auth headers
function getAuthHeaders() {
  const token = localStorage.getItem(TOKEN_KEY);
  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`,
  };
}

// Load dashboard
async function loadDashboard() {
  try {
    const res = await fetch(`${API_BASE}/api/admin/dashboard/stats`, {
      headers: getAuthHeaders(),
    });

    if (!res.ok) throw new Error('Error loading dashboard');

    const stats = await res.json();

    document.getElementById('stat-total-apartments').textContent = stats.totalApartments;
    document.getElementById('stat-available').textContent = stats.available;
    document.getElementById('stat-sold').textContent = stats.sold;
    document.getElementById('stat-new-contacts').textContent = stats.newContacts;

    // Load apartments table by default
    loadApartmentsTable();
  } catch (err) {
    console.error('Error loading dashboard:', err);
    showToast('Error cargando panel', 'error');
  }
}

// Load apartments table
async function loadApartmentsTable() {
  const container = document.getElementById('admin-content');
  showLoading(container);

  try {
    const res = await fetch(`${API_BASE}/api/apartments?limit=100`, {
      headers: getAuthHeaders(),
    });

    const data = await res.json();
    const apartments = data.apartments;

    hideLoading(container);

    const html = `
      <div style="margin-bottom: 1.5rem;">
        <button class="btn btn-primary" onclick="openAddApartmentModal()">
          <i class="fas fa-plus"></i> Agregar Nuevo
        </button>
      </div>
      <div class="admin-table-container">
        <table class="admin-table">
          <thead>
            <tr>
              <th>Imagen</th>
              <th>Título</th>
              <th>Precio</th>
              <th>Ciudad</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            ${apartments.map(apt => `
              <tr>
                <td><img src="${apt.mainImage || apt.images[0]}" style="width: 50px; height: 50px; border-radius: 5px; object-fit: cover;"></td>
                <td>${apt.title.substring(0, 30)}...</td>
                <td>${formatPrice(apt.price)}</td>
                <td>${apt.address.city}</td>
                <td><span class="badge badge-${apt.status}">${apt.status}</span></td>
                <td>
                  <div class="table-actions">
                    <button class="btn-edit" onclick="editApartment('${apt._id}')">Editar</button>
                    <button class="btn-delete" onclick="deleteApartment('${apt._id}', '${apt.title}')">Eliminar</button>
                  </div>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;

    container.innerHTML = html;
    currentTab = 'apartments';
  } catch (err) {
    hideLoading(container);
    console.error('Error loading apartments:', err);
    showToast('Error cargando departamentos', 'error');
  }
}

// Load contacts table
async function loadContactsTable() {
  const container = document.getElementById('admin-content');
  showLoading(container);

  try {
    const res = await fetch(`${API_BASE}/api/contacts`, {
      headers: getAuthHeaders(),
    });

    const contacts = await res.json();

    hideLoading(container);

    const html = `
      <div class="admin-table-container">
        <table class="admin-table">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Email</th>
              <th>Teléfono</th>
              <th>Departamento</th>
              <th>Estado</th>
              <th>Fecha</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            ${contacts.map(contact => `
              <tr>
                <td>${contact.name}</td>
                <td>${contact.email}</td>
                <td>${contact.phone}</td>
                <td>${contact.apartmentTitle || '—'}</td>
                <td>
                  <select onchange="updateContactStatus('${contact._id}', this.value)" style="padding: 0.5rem; border: 1px solid #ddd; border-radius: 3px;">
                    <option value="nuevo" ${contact.status === 'nuevo' ? 'selected' : ''}>Nuevo</option>
                    <option value="contactado" ${contact.status === 'contactado' ? 'selected' : ''}>Contactado</option>
                    <option value="cerrado" ${contact.status === 'cerrado' ? 'selected' : ''}>Cerrado</option>
                  </select>
                </td>
                <td>${formatDate(contact.createdAt)}</td>
                <td><small>${contact.message.substring(0, 20)}...</small></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;

    container.innerHTML = html;
    currentTab = 'contacts';
  } catch (err) {
    hideLoading(container);
    console.error('Error loading contacts:', err);
    showToast('Error cargando contactos', 'error');
  }
}

// Open add apartment modal
function openAddApartmentModal() {
  const modal = document.getElementById('apartment-modal');
  const form = document.getElementById('apartment-form');

  form.reset();
  document.getElementById('modal-title').textContent = 'Agregar Nuevo Departamento';
  document.getElementById('apartment-id').value = '';

  modal.classList.add('show');
}

// Edit apartment
async function editApartment(id) {
  try {
    const res = await fetch(`${API_BASE}/api/apartments/${id}`);
    const apartment = await res.json();

    document.getElementById('apartment-id').value = apartment._id;
    document.getElementById('apartment-title').value = apartment.title;
    document.getElementById('apartment-description').value = apartment.description;
    document.getElementById('apartment-price').value = apartment.price;
    document.getElementById('apartment-bedrooms').value = apartment.details.bedrooms || '';
    document.getElementById('apartment-bathrooms').value = apartment.details.bathrooms || '';
    document.getElementById('apartment-area').value = apartment.details.area || '';
    document.getElementById('apartment-floor').value = apartment.details.floor || '';
    document.getElementById('apartment-neighborhood').value = apartment.address.neighborhood || '';
    document.getElementById('apartment-city').value = apartment.address.city || '';
    document.getElementById('apartment-status').value = apartment.status;
    document.getElementById('apartment-type').value = apartment.type;
    document.getElementById('apartment-featured').checked = apartment.featured;
    document.getElementById('apartment-main-image').value = apartment.mainImage || '';

    document.getElementById('modal-title').textContent = 'Editar Departamento';
    document.getElementById('apartment-modal').classList.add('show');
  } catch (err) {
    console.error('Error loading apartment:', err);
    showToast('Error cargando departamento', 'error');
  }
}

// Save apartment
async function saveApartment(e) {
  e.preventDefault();

  const id = document.getElementById('apartment-id').value;
  const formData = {
    title: document.getElementById('apartment-title').value,
    description: document.getElementById('apartment-description').value,
    price: parseInt(document.getElementById('apartment-price').value),
    address: {
      street: '',
      neighborhood: document.getElementById('apartment-neighborhood').value,
      city: document.getElementById('apartment-city').value,
      state: document.getElementById('apartment-city').value,
      zipCode: '',
      country: 'México',
    },
    details: {
      bedrooms: parseInt(document.getElementById('apartment-bedrooms').value) || 0,
      bathrooms: parseInt(document.getElementById('apartment-bathrooms').value) || 0,
      area: parseInt(document.getElementById('apartment-area').value) || 0,
      floor: parseInt(document.getElementById('apartment-floor').value) || 0,
      parking: false,
      furnished: false,
      petFriendly: false,
    },
    mainImage: document.getElementById('apartment-main-image').value,
    images: [document.getElementById('apartment-main-image').value],
    status: document.getElementById('apartment-status').value,
    type: document.getElementById('apartment-type').value,
    featured: document.getElementById('apartment-featured').checked,
    amenities: [],
  };

  const method = id ? 'PUT' : 'POST';
  const url = id ? `${API_BASE}/api/apartments/${id}` : `${API_BASE}/api/apartments`;

  try {
    const res = await fetch(url, {
      method,
      headers: getAuthHeaders(),
      body: JSON.stringify(formData),
    });

    if (!res.ok) throw new Error('Error saving apartment');

    showToast(id ? 'Departamento actualizado' : 'Departamento creado', 'success');
    document.getElementById('apartment-modal').classList.remove('show');
    loadApartmentsTable();
  } catch (err) {
    console.error('Error saving apartment:', err);
    showToast('Error guardando departamento', 'error');
  }
}

// Delete apartment
async function deleteApartment(id, title) {
  if (!confirm(`¿Está seguro de que desea eliminar "${title}"?`)) return;

  try {
    const res = await fetch(`${API_BASE}/api/apartments/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });

    if (!res.ok) throw new Error('Error deleting apartment');

    showToast('Departamento eliminado', 'success');
    loadApartmentsTable();
  } catch (err) {
    console.error('Error deleting apartment:', err);
    showToast('Error eliminando departamento', 'error');
  }
}

// Update contact status
async function updateContactStatus(id, status) {
  try {
    const res = await fetch(`${API_BASE}/api/contacts/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ status }),
    });

    if (!res.ok) throw new Error('Error updating contact');

    showToast('Estado actualizado', 'success');
  } catch (err) {
    console.error('Error updating contact:', err);
    showToast('Error actualizando estado', 'error');
  }
}

// Modal functions
function closeModal() {
  document.getElementById('apartment-modal').classList.remove('show');
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', handleLogin);
  }

  const apartmentForm = document.getElementById('apartment-form');
  if (apartmentForm) {
    apartmentForm.addEventListener('submit', saveApartment);
  }

  // Tab switching
  document.querySelectorAll('.admin-tab').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      document.querySelectorAll('.admin-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      if (btn.textContent.includes('Departamentos')) {
        loadApartmentsTable();
      } else {
        loadContactsTable();
      }
    });
  });

  checkAuth();
});
