// Get URL params
function getContactParams() {
  const params = new URLSearchParams(window.location.search);
  return {
    apartmentId: params.get('apartmentId') || '',
    apartmentTitle: params.get('apartmentTitle') || '',
  };
}

// Handle contact form submit
async function submitContactForm(e) {
  e.preventDefault();

  const params = getContactParams();

  const formData = {
    name: document.getElementById('name').value,
    email: document.getElementById('email').value,
    phone: document.getElementById('phone').value,
    message: document.getElementById('message').value,
    apartmentId: params.apartmentId || null,
    apartmentTitle: params.apartmentTitle || null,
  };

  const submitBtn = e.target.querySelector('.btn-submit');
  const originalText = submitBtn.textContent;
  submitBtn.disabled = true;
  submitBtn.textContent = 'Enviando...';

  try {
    const res = await fetch(`${API_BASE}/api/contacts`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData),
    });

    if (!res.ok) throw new Error('Error al enviar');

    showToast('¡Consulta enviada exitosamente! Te contactaremos pronto.', 'success');
    e.target.reset();
  } catch (err) {
    console.error('Error submitting contact:', err);
    showToast('Error al enviar consulta. Intenta de nuevo.', 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.textContent = originalText;
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  const params = getContactParams();

  // Pre-fill apartment title if coming from detail page
  if (params.apartmentTitle) {
    const apartmentField = document.getElementById('apartment-interest');
    if (apartmentField) {
      apartmentField.value = decodeURIComponent(params.apartmentTitle);
    }
  }

  // Setup form submit
  const form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', submitContactForm);
  }
});
