const API_BASE = '';

// Format price in MXN
function formatPrice(price) {
  return new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(price);
}

// Format date in Spanish
function formatDate(dateString) {
  const options = {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  };
  return new Intl.DateTimeFormat('es-MX', options).format(new Date(dateString));
}

// Create apartment card HTML
function createApartmentCard(apt) {
  const statusBadge = getStatusBadge(apt.status);
  const priceFormatted = formatPrice(apt.price);

  return `
    <div class="property-card">
      <div class="property-image">
        <img src="${apt.mainImage || apt.images[0]}" alt="${apt.title}" loading="lazy">
        <div class="property-badge badge-${apt.status}">${apt.status.toUpperCase()}</div>
        <div class="property-price">${priceFormatted}</div>
      </div>
      <div class="property-info">
        <h3 class="property-title">${apt.title}</h3>
        <p class="property-location">
          <i class="fas fa-map-marker-alt"></i>
          ${apt.address.neighborhood}, ${apt.address.city}
        </p>
        <div class="property-details">
          ${apt.details.bedrooms ? `<div class="detail-pill"><i class="fas fa-bed"></i> ${apt.details.bedrooms} Recámaras</div>` : ''}
          ${apt.details.bathrooms ? `<div class="detail-pill"><i class="fas fa-bath"></i> ${apt.details.bathrooms} Baños</div>` : ''}
          ${apt.details.area ? `<div class="detail-pill"><i class="fas fa-ruler"></i> ${apt.details.area} m²</div>` : ''}
        </div>
        <p class="property-description">${apt.description.substring(0, 100)}...</p>
        <div class="property-footer">
          <button class="btn-view" onclick="viewProperty('${apt._id}')">Ver Detalles</button>
          <button class="btn-contact" onclick="contactProperty('${apt._id}', '${apt.title}')">Contactar</button>
        </div>
      </div>
    </div>
  `;
}

// Get status badge HTML
function getStatusBadge(status) {
  const badges = {
    disponible: '<span class="badge bg-success">Disponible</span>',
    vendido: '<span class="badge bg-danger">Vendido</span>',
    apartado: '<span class="badge bg-warning">Apartado</span>',
  };
  return badges[status] || '';
}

// Show toast notification
function showToast(message, type = 'info') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 3000);
}

// Show loading spinner
function showLoading(container) {
  const element = typeof container === 'string' ? document.querySelector(container) : container;
  if (element) {
    element.innerHTML = '<div class="loading-container"><div class="loading"></div></div>';
  }
}

// Hide loading spinner
function hideLoading(container) {
  const element = typeof container === 'string' ? document.querySelector(container) : container;
  if (element) {
    const loading = element.querySelector('.loading-container');
    if (loading) {
      loading.remove();
    }
  }
}

// Navigate to property detail
function viewProperty(id) {
  window.location.href = `/detalle.html?id=${id}`;
}

// Navigate to contact with apartment pre-selected
function contactProperty(id, title) {
  window.location.href = `/contacto.html?apartmentId=${id}&apartmentTitle=${encodeURIComponent(title)}`;
}

// Animate numbers
function animateNumbers() {
  const numbers = document.querySelectorAll('.stat-number');
  numbers.forEach(el => {
    const target = parseInt(el.textContent);
    let current = 0;
    const increment = Math.ceil(target / 50);
    const interval = setInterval(() => {
      current += increment;
      if (current >= target) {
        el.textContent = target.toLocaleString('es-MX');
        clearInterval(interval);
      } else {
        el.textContent = current.toLocaleString('es-MX');
      }
    }, 30);
  });
}

// Load featured apartments on index page
function loadFeaturedApartments() {
  const container = document.getElementById('featured-apartments');
  if (!container) return;

  showLoading(container);

  fetch(`${API_BASE}/api/apartments/featured`)
    .then(res => res.json())
    .then(apartments => {
      hideLoading(container);
      if (apartments.length > 0) {
        container.innerHTML = apartments.map(apt => createApartmentCard(apt)).join('');
      } else {
        container.innerHTML = '<p>No hay departamentos destacados en este momento.</p>';
      }
    })
    .catch(err => {
      hideLoading(container);
      console.error('Error loading featured apartments:', err);
      showToast('Error al cargar departamentos', 'error');
    });
}

// DOMContentLoaded
document.addEventListener('DOMContentLoaded', () => {
  loadFeaturedApartments();

  // Animate numbers on page load
  if (document.querySelector('.stat-number')) {
    setTimeout(() => {
      animateNumbers();
    }, 500);
  }

  // Set active nav link
  const currentPath = window.location.pathname;
  document.querySelectorAll('.nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (currentPath.endsWith(href) || (currentPath === '/' && href === 'index.html')) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });
});
