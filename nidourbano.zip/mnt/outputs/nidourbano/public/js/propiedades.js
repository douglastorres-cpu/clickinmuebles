let currentPage = 1;
let currentFilters = {};

// Parse URL params
function getUrlParams() {
  const params = new URLSearchParams(window.location.search);
  return {
    search: params.get('search') || '',
    city: params.get('city') || '',
    bedrooms: params.get('bedrooms') || '',
    minPrice: params.get('minPrice') || '',
    maxPrice: params.get('maxPrice') || '',
    type: params.get('type') || '',
    status: params.get('status') || '',
  };
}

// Fetch apartments with filters
async function fetchApartments(page = 1, filters = {}) {
  const params = new URLSearchParams();

  params.append('page', page);
  params.append('limit', 9);

  if (filters.search) params.append('search', filters.search);
  if (filters.city) params.append('city', filters.city);
  if (filters.bedrooms) params.append('bedrooms', filters.bedrooms);
  if (filters.minPrice) params.append('minPrice', filters.minPrice);
  if (filters.maxPrice) params.append('maxPrice', filters.maxPrice);
  if (filters.type) params.append('type', filters.type);
  if (filters.status) params.append('status', filters.status);

  const container = document.getElementById('apartments-grid');
  const resultsCount = document.getElementById('results-count');

  showLoading(container);

  try {
    const res = await fetch(`${API_BASE}/api/apartments?${params}`);
    const data = await res.json();

    hideLoading(container);

    if (data.apartments.length > 0) {
      container.innerHTML = data.apartments.map(apt => createApartmentCard(apt)).join('');
      resultsCount.textContent = `${data.pagination.total} departamentos encontrados`;
      renderPagination(data.pagination);
    } else {
      container.innerHTML = '<p style="grid-column: 1 / -1; text-align: center; padding: 2rem;">No se encontraron departamentos con los criterios de búsqueda.</p>';
      resultsCount.textContent = '0 departamentos encontrados';
      document.getElementById('pagination').innerHTML = '';
    }

    currentPage = page;
    currentFilters = filters;
  } catch (err) {
    hideLoading(container);
    console.error('Error fetching apartments:', err);
    showToast('Error al cargar departamentos', 'error');
  }
}

// Render pagination
function renderPagination(pagination) {
  const paginationDiv = document.getElementById('pagination');
  paginationDiv.innerHTML = '';

  if (pagination.pages <= 1) return;

  // Previous button
  if (pagination.page > 1) {
    const prevBtn = document.createElement('button');
    prevBtn.className = 'page-link';
    prevBtn.textContent = '← Anterior';
    prevBtn.onclick = () => fetchApartments(pagination.page - 1, currentFilters);
    paginationDiv.appendChild(prevBtn);
  }

  // Page numbers
  for (let i = 1; i <= pagination.pages; i++) {
    if (i >= pagination.page - 2 && i <= pagination.page + 2) {
      const btn = document.createElement('button');
      btn.className = `page-link ${i === pagination.page ? 'active' : ''}`;
      btn.textContent = i;
      btn.onclick = () => fetchApartments(i, currentFilters);
      paginationDiv.appendChild(btn);
    }
  }

  // Next button
  if (pagination.page < pagination.pages) {
    const nextBtn = document.createElement('button');
    nextBtn.className = 'page-link';
    nextBtn.textContent = 'Siguiente →';
    nextBtn.onclick = () => fetchApartments(pagination.page + 1, currentFilters);
    paginationDiv.appendChild(nextBtn);
  }
}

// Handle filter form submit
function handleFilterSubmit(e) {
  e.preventDefault();

  const filters = {
    search: document.getElementById('search').value,
    city: document.getElementById('city').value,
    bedrooms: document.getElementById('bedrooms').value,
    minPrice: document.getElementById('minPrice').value,
    maxPrice: document.getElementById('maxPrice').value,
    type: document.getElementById('type').value,
    status: document.getElementById('status').value,
  };

  // Update URL
  const params = new URLSearchParams();
  Object.keys(filters).forEach(key => {
    if (filters[key]) params.append(key, filters[key]);
  });
  window.history.pushState({}, '', `?${params}`);

  fetchApartments(1, filters);
}

// Handle sort change
function handleSort(e) {
  const sortValue = e.target.value;
  const container = document.getElementById('apartments-grid');
  const cards = Array.from(container.querySelectorAll('.property-card'));

  cards.sort((a, b) => {
    const priceA = parseInt(a.querySelector('.property-price').textContent.replace(/[^0-9]/g, ''));
    const priceB = parseInt(b.querySelector('.property-price').textContent.replace(/[^0-9]/g, ''));

    if (sortValue === 'price-asc') {
      return priceA - priceB;
    } else if (sortValue === 'price-desc') {
      return priceB - priceA;
    }
    return 0;
  });

  container.innerHTML = cards.map(card => card.outerHTML).join('');
}

// Initialize page
document.addEventListener('DOMContentLoaded', () => {
  const urlParams = getUrlParams();

  // Set filter values from URL
  Object.keys(urlParams).forEach(key => {
    const el = document.getElementById(key);
    if (el && urlParams[key]) {
      el.value = urlParams[key];
    }
  });

  // Load apartments
  fetchApartments(1, urlParams);

  // Setup event listeners
  const filterForm = document.getElementById('filter-form');
  if (filterForm) {
    filterForm.addEventListener('submit', handleFilterSubmit);
  }

  const sortSelect = document.getElementById('sort');
  if (sortSelect) {
    sortSelect.addEventListener('change', handleSort);
  }
});
